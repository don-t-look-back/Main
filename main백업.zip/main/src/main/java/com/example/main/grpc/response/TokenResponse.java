package com.example.main.grpc.response;

import lombok.Builder;

@Builder
public class TokenResponse {
    Long memberId;
}
