package com.example.main.grpc.request;

import lombok.Builder;

@Builder
public class TokenRequest {
    String token;
}
